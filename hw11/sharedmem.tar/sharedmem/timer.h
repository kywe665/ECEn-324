/* function prototypes for the contents of timer.c */

void access_counter(unsigned *hi, unsigned *lo);
void start_counter(void);
unsigned get_counter(void);
double dget_counter(void);
void display_CPUspeed(void);
