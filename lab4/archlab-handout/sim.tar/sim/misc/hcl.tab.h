#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	QUOTE	257
#define	BOOLARG	258
#define	BOOL	259
#define	INTARG	260
#define	INT	261
#define	QSTRING	262
#define	VAR	263
#define	NUM	264
#define	ASSIGN	265
#define	SEMI	266
#define	COLON	267
#define	COMMA	268
#define	LPAREN	269
#define	RPAREN	270
#define	LBRACE	271
#define	RBRACE	272
#define	LBRACK	273
#define	RBRACK	274
#define	AND	275
#define	OR	276
#define	NOT	277
#define	COMP	278
#define	IN	279


extern YYSTYPE yylval;
