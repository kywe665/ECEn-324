#include <stdio.h>

double x;

int p2()
{
    x = 21913.57895;
}
